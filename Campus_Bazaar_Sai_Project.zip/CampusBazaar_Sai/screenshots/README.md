# Screenshots for assignment evidence

After running the project, add genuine screenshots here:
- `homepage.png` — site opened in a browser
- `mobile-view.png` — responsive mobile layout
- `commit-history.png` — GitHub commits showing incremental work
- `actions-success.png` — successful GitHub Actions run
- `pages-live.png` — GitHub Pages deployment / live site

These are intentionally not fabricated; capture them after the real steps are complete.
